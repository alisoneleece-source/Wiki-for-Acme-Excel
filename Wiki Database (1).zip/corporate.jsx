/* global React */
// ---- Corporate Info ----
// Source of truth: the "ZV Corporate Info" master Google Doc. Every data point
// below renders as a link back to that document so anyone can verify or expand.
const CORP_DOC_URL =
  "https://docs.google.com/document/d/1SZ6JzzCNVKJPcYN1drDPsq6vM30XKOYXlhot9J9cC44/edit";

const CORP_ENTITIES = [
  {
    id: "dronebase-inc",
    name: "DroneBase Inc.",
    dba: "dba Zeitview",
    country: "USA",
    flag: "🇺🇸",
    type: "C-Corp",
    primary: true,
    meta: [
      { label: "Registered in", value: "Delaware" },
      { label: "Formed", value: "July 16, 2014" },
    ],
    fields: [
      { label: "Registered address", value: "251 Little Falls Drive, Wilmington, Delaware 19808" },
      { label: "Head office", value: "4275 Executive Square, Suite 200 #1004, San Diego, CA 92037, United States" },
      { label: "Phone", value: "1 (805) 600-0591 (routed to Zendesk)", mono: true },
      { label: "Tax year end", value: "December 31" },
      { label: "Tax number (FEIN)", value: "47-1365569", mono: true, key: true },
      { label: "Registration no.", value: "5564179", mono: true },
      { label: "Secondary reg.", value: "SR20244179620", mono: true },
      { label: "DUNS", value: "079751381", mono: true, key: true },
      { label: "NAICS", value: "541922", mono: true, key: true },
      { label: "SIC", value: "7335", mono: true },
      { label: "Verticals", values: ["Properties (original)", "Wind", "Solar", "Utilities (Clearsight)", "Geospatial"] },
      { label: "Directors", values: ["Dan Burton", "Mark Suster", "Vivek Pattipati", "Mike Bishop", "Scott Stephenson (Chair)", "Jake Van Koevering"] },
      { label: "Officers / signatories", values: ["Dan Burton", "Ryan Waring", "Matt Falk", "Jocelyne Moyer", "Scott Johnson", "Jared Gillespie"] },
      { label: "Billing contact", value: "Bry Guentert · bryanna.guentert@zeitview.com · 623-251-0485" },
    ],
  },
  {
    id: "insight-m",
    name: "Insight M Inc.",
    country: "USA",
    flag: "🇺🇸",
    type: "C-Corp",
    meta: [
      { label: "Registered in", value: "Delaware" },
      { label: "Acquired", value: "Jan 28, 2026" },
      { label: "Formation", value: "Formed via merger with Project Osprey Merger Co." },
    ],
    fields: [
      { label: "Registered address", value: "850 New Burton Road, Suite 201, City of Dover, County of Kent, Delaware 19904" },
      { label: "Head office", value: "928 Benecia Ave, Sunnyvale, CA 94085, United States" },
      { label: "Tax year end", value: "December 31" },
      { label: "Tax number", value: "46-4382581", mono: true, key: true },
      { label: "Registration no.", value: "5455251", mono: true },
      { label: "Secondary reg.", value: "SR20260339108", mono: true },
      { label: "CAGE code", value: "722N5", mono: true, key: true },
      { label: "Verticals", values: ["Oil and Gas"] },
      { label: "Directors", values: ["Dan Burton"] },
      { label: "Officers / signatories", values: ["Dan Burton"] },
      { label: "Key customers", values: ["Oxy", "Targa", "BPX", "Coterra"] },
    ],
  },
  {
    id: "dronebase-europe",
    name: "DroneBase Europe GmbH",
    country: "Germany",
    flag: "🇩🇪",
    type: "Company with Limited Liability",
    meta: [
      { label: "Founded", value: "May 20, 2020" },
      { label: "Acquired", value: "2022" },
    ],
    fields: [
      { label: "Registered address", value: "Mittelstraße 11, 40789 Monheim am Rhein, Germany" },
      { label: "Head office", value: "Mittelstraße 11, 40789 Monheim am Rhein, Germany" },
      { label: "Tax year end", value: "December 31" },
      { label: "Tax number", value: "DE 331311557", mono: true, key: true },
      { label: "USt-IdNr / W-IdNr", value: "USt-IdNr DE331311557 · W-IdNr DE331311557-00001", mono: true },
      { label: "Registration no.", value: "HRB 721941", mono: true },
      { label: "EORI number", value: "DE840750759376277", mono: true, key: true },
      { label: "NACE (WZ Nummer)", value: "63.11.0", mono: true },
      { label: "Verticals", values: ["Wind (primary)", "Solar", "2025 expansion: Property"] },
      { label: "Directors", values: ["Sven Affuepper", "Dan Burton"] },
      { label: "Officers / signatories", values: ["Dan Burton"] },
      { label: "Key customers", values: ["GE"] },
    ],
  },
  {
    id: "zeitview-apac",
    name: "Zeitview APAC Pvt Ltd",
    country: "India",
    flag: "🇮🇳",
    type: "Private Limited Company",
    meta: [
      { label: "Registered in", value: "Bangalore" },
      { label: "Founded", value: "2023" },
    ],
    fields: [
      { label: "Registered address", value: "BHIVE Workspace – No.112, AKR Tech Park, B Block, 7th Mile Hosur Rd, Krishna Reddy Industrial Area, Bengaluru, Karnataka 560068" },
      { label: "Head office", value: "Uma Sree Dream World B-Block, Bhive Workspace, No.112, 1st floor, AKR Tech Park, 7th Mile Hosur Road, Krishna Reddy Industrial Area, Bangalore 560068" },
      { label: "Tax year end", value: "March 31" },
      { label: "Registration no. (CIN)", value: "U74999KA2017PTC106100", mono: true, key: true },
      { label: "Verticals", values: ["Solar", "Wind"] },
      { label: "Directors", values: ["Harsh Desai", "Dan Burton", "Nick Osgood"] },
      { label: "Officers / signatories", values: ["Harsh Desai", "Dan Burton"] },
    ],
  },
  {
    id: "zeitview-latam",
    name: "Zeitview Latin American Ltd",
    country: "Brazil",
    flag: "🇧🇷",
    meta: [
      { label: "Founded", value: "2023 (to acquire Heliolytics)" },
    ],
    fields: [
      { label: "Registered address", value: "Ave Rio Branco 89 (unit 802), Rio de Janeiro, Brazil" },
      { label: "Head office", value: "Avenida Rio Branco 89, sala 802, Centro, Rio de Janeiro 20040-004" },
      { label: "Tax year end", value: "December 31" },
      { label: "Verticals", values: ["Wind (primary)", "Solar (rarely)"] },
      { label: "Directors", values: ["Anderson Derossi"] },
      { label: "Officers / signatories", values: ["Anderson Derossi"] },
      { label: "Key customers", values: ["GE"] },
    ],
  },
  {
    id: "zeitview-canada",
    name: "Zeitview Canada Inc.",
    country: "Canada",
    flag: "🇨🇦",
    type: "Corporation",
    meta: [
      { label: "Registered in", value: "Ontario" },
    ],
    fields: [
      { label: "Registered address", value: "802 – 130 Spadina Ave, Toronto, Ontario Canada M5V 2L4" },
      { label: "Head office", value: "802 – 130 Spadina Ave, Toronto, Ontario Canada M5V 2L4" },
      { label: "Tax year end", value: "December 31" },
      { label: "Tax number", value: "793130352", mono: true, key: true },
      { label: "Registration no.", value: "1000632545", mono: true },
      { label: "Verticals", values: ["Solar (manned aircraft)", "Expansion: Wind, Geospatial"] },
      { label: "Directors", values: ["Dan Burton", "Nick Osgood"] },
      { label: "Officers / signatories", values: ["Dan Burton"] },
    ],
  },
];

// A data point that links back to the master corporate doc.
function DocValue({ children, mono, isKey, title }) {
  return (
    <a
      className={"corp-link" + (mono ? " mono" : "") + (isKey ? " key" : "")}
      href={CORP_DOC_URL}
      target="_blank"
      rel="noopener noreferrer"
      title={title || "Open in ZV Corporate Info doc"}
    >
      {children}
    </a>
  );
}

function CorpIcon({ name }) {
  if (name === "doc") {
    return (
      <svg viewBox="0 0 16 16" width="14" height="14" aria-hidden>
        <path d="M4 1.5 H9.5 L13 5 V14 a0.6 0.6 0 0 1 -0.6 0.6 H4 a0.6 0.6 0 0 1 -0.6 -0.6 V2.1 A0.6 0.6 0 0 1 4 1.5 Z" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
        <path d="M9.3 1.7 V5 H12.8 M5.6 8 H10.4 M5.6 10.4 H10.4" fill="none" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
      </svg>
    );
  }
  if (name === "arrow") {
    return (
      <svg viewBox="0 0 16 16" width="13" height="13" aria-hidden>
        <path d="M5 11 L11 5 M6.2 5 H11 V9.8" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
  }
  return null;
}

function CorpCard({ entity }) {
  return (
    <article className={"corp-card" + (entity.inactive ? " corp-inactive" : "") + (entity.primary ? " corp-primary" : "")}>
      <header className="corp-card-head">
        <div className="corp-flag" aria-hidden>{entity.flag}</div>
        <div className="corp-id">
          <div className="corp-name">
            {entity.name}
            {entity.status && <span className="corp-status">{entity.status}</span>}
          </div>
          <div className="corp-sub">
            {entity.dba && <span className="corp-dba">{entity.dba}</span>}
            <span className="corp-country">{entity.country}</span>
            {entity.type && <><span className="corp-bdot">·</span><span>{entity.type}</span></>}
          </div>
        </div>
      </header>

      {entity.meta && entity.meta.length > 0 && (
        <div className="corp-meta">
          {entity.meta.map((m) => (
            <div key={m.label} className="corp-meta-item">
              <span className="corp-meta-label">{m.label}</span>
              <DocValue title={m.label}>{m.value}</DocValue>
            </div>
          ))}
        </div>
      )}

      <dl className="corp-fields">
        {entity.fields.map((f) => (
          <div key={f.label} className="corp-field">
            <dt>{f.label}</dt>
            <dd>
              {f.values ? (
                <span className="corp-chips">
                  {f.values.map((v, i) => (
                    <DocValue key={i} title={f.label}>{v}</DocValue>
                  ))}
                </span>
              ) : (
                <DocValue mono={f.mono} isKey={f.key} title={f.label}>{f.value}</DocValue>
              )}
            </dd>
          </div>
        ))}
      </dl>
    </article>
  );
}

function CorporateView() {
  const { useState, useMemo } = React;
  const [q, setQ] = useState("");
  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return CORP_ENTITIES;
    return CORP_ENTITIES.filter((e) => {
      const hay = (e.name + " " + e.country + " " + (e.type || "") + " " +
        e.fields.map((f) => (f.value || "") + " " + (f.values || []).join(" ")).join(" ")).toLowerCase();
      return hay.includes(needle);
    });
  }, [q]);

  const activeCount = CORP_ENTITIES.filter((e) => !e.inactive).length;
  const countryCount = new Set(CORP_ENTITIES.filter((e) => !e.inactive).map((e) => e.country)).size;

  return (
    <div className="page page-corporate">
      <div className="page-head">
        <div className="page-eyebrow">CORPORATE INFO</div>
        <h1 className="page-title">Legal entities &amp; registrations</h1>
        <p className="page-sub">
          The Zeitview group of companies — {activeCount} active entities across {countryCount} countries.
          Every field links straight to the master <b>ZV Corporate Info</b> doc, the single source of truth for tax IDs, addresses, and registrations.
        </p>
      </div>

      <a className="corp-source" href={CORP_DOC_URL} target="_blank" rel="noopener noreferrer">
        <span className="corp-source-icon"><CorpIcon name="doc" /></span>
        <span className="corp-source-text">
          <b>ZV Corporate Info</b>
          <span>Master Google Doc · click any value below to open it</span>
        </span>
        <span className="corp-source-go">Open doc <CorpIcon name="arrow" /></span>
      </a>

      <div className="corp-toolbar">
        <div className="corp-search">
          <svg viewBox="0 0 20 20" width="17" height="17" aria-hidden>
            <circle cx="9" cy="9" r="6" fill="none" stroke="currentColor" strokeWidth="1.6" />
            <path d="M14 14 L18 18" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          </svg>
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Filter entities — name, country, tax ID, address…"
            aria-label="Filter corporate entities"
          />
          {q && <button className="corp-search-clear" onClick={() => setQ("")} aria-label="Clear">✕</button>}
        </div>
        <div className="corp-count">{filtered.length} of {CORP_ENTITIES.length} entities</div>
      </div>

      <div className="corp-grid">
        {filtered.map((e) => <CorpCard key={e.id} entity={e} />)}
        {filtered.length === 0 && (
          <div className="corp-empty">No entities match “<b>{q}</b>”.</div>
        )}
      </div>

      <div className="corp-footnote">
        <span className="corp-foot-label">Also in the doc</span>
        <a className="corp-link" href={CORP_DOC_URL} target="_blank" rel="noopener noreferrer">
          Schedule of Insurance Portfolio for DroneBase Inc. (worldwide coverage for subsidiaries noted in the comments) <CorpIcon name="arrow" />
        </a>
      </div>
    </div>
  );
}

window.CorporateView = CorporateView;
