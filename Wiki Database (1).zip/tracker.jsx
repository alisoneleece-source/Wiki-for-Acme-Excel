/* global React */
// ---- Compliance Platforms & Insurance trackers ----
// Simple editable-by-request lists of vendor companies with renewal/expiration dates.
// No entries yet — add companies by telling the wiki editor what to include.

const COMPLIANCE_PLATFORMS = [];
const INSURANCE_POLICIES = [];

function daysUntil(dateStr) {
  if (!dateStr) return null;
  const d = new Date(dateStr);
  if (isNaN(d)) return null;
  return Math.ceil((d - new Date()) / 86400000);
}

function ExpiryBadge({ date }) {
  const days = daysUntil(date);
  if (days === null) return <span className="tr-badge tr-badge-none">No date</span>;
  if (days < 0) return <span className="tr-badge tr-badge-expired">Expired</span>;
  if (days <= 60) return <span className="tr-badge tr-badge-soon">Due soon</span>;
  return <span className="tr-badge tr-badge-active">Active</span>;
}

function TrackerTable({ rows, columns, emptyLabel }) {
  if (!rows.length) {
    return (
      <div className="tr-empty">
        <p>No {emptyLabel} yet.</p>
        <p className="tr-empty-hint">Tell me the companies and their renewal or expiration dates, and I’ll add them here.</p>
      </div>
    );
  }
  return (
    <div className="tr-table-wrap">
      <table className="tr-table">
        <thead>
          <tr>{columns.map((c) => <th key={c}>{c}</th>)}<th>Status</th></tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i}>
              <td className="tr-name">{r.name}</td>
              <td>{r.type}</td>
              <td>{r.date || "—"}</td>
              <td>{r.notes || "—"}</td>
              <td><ExpiryBadge date={r.date} /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function CompliancePlatformsView() {
  return (
    <div className="page page-tracker">
      <div className="page-head">
        <div className="page-eyebrow">COMPLIANCE PLATFORMS</div>
        <h1 className="page-title">Vendor compliance platforms</h1>
        <p className="page-sub">Third-party compliance tracking platforms (e.g. Avetta, ISNetworld, Veriforce) and when registrations or certifications are due.</p>
      </div>
      <TrackerTable
        rows={COMPLIANCE_PLATFORMS}
        columns={["Platform / Company", "Type", "Renewal / due date", "Notes"]}
        emptyLabel="compliance platforms"
      />
    </div>
  );
}

function InsuranceView() {
  return (
    <div className="page page-tracker">
      <div className="page-head">
        <div className="page-eyebrow">INSURANCE</div>
        <h1 className="page-title">Insurance policies &amp; coverage</h1>
        <p className="page-sub">Insurance carriers, policy types, and expiration dates.</p>
      </div>
      <TrackerTable
        rows={INSURANCE_POLICIES}
        columns={["Carrier / Company", "Coverage type", "Expiration date", "Notes"]}
        emptyLabel="insurance policies"
      />
    </div>
  );
}

Object.assign(window, { CompliancePlatformsView, InsuranceView });
