/* global React, ReactDOM */
const { useState, useEffect, useMemo, useRef } = React;

// ---- Editor access ----
// Only people who know this passcode can switch the wiki into editor mode and
// edit entries. NOTE: this is a client-side gate (the file has no server), so it
// keeps editing out of casual reach but is not hardened security.
// To change the passcode, replace the char codes below with your own. Quick way:
//   in the browser console run:  [...'yourcode'].map(c=>c.charCodeAt(0))
// then paste the resulting array here.
const EDITOR_PASSCODE = String.fromCharCode(122,101,105,116,118,105,101,119,50,48,50,54); // "zeitview2026"

// ---- Tweaks: persistent defaults ----
const TWEAKS = /*EDITMODE-BEGIN*/{
  "primaryColor": "#5B48FB",
  "accentTint": "#EFECFF",
  "cardDensity": "comfortable",
  "showReplyCount": true,
  "heroStyle": "gradient"
}/*EDITMODE-END*/;

// ---- Helpers ----
const CATEGORIES_ORDER = [
  "Vendor Portals & Registration",
  "Finance",
  "Legal",
  "Company Info",
  "Safety & Compliance",
  "Sustainability",
  "Insurance",
];

const CATEGORY_SHORT = {
  "Vendor Portals & Registration": "Portals",
  "Finance": "Finance",
  "Legal": "Legal",
  "Company Info": "Company",
  "Safety & Compliance": "Safety",
  "Sustainability": "ESG",
  "Insurance": "Insurance",
};

function parseDate(s) {
  // "Jul 30, 2024"
  if (!s) return 0;
  const d = new Date(s);
  return isNaN(d) ? 0 : d.getTime();
}

function initials(name) {
  if (!name) return "··";
  const parts = name.trim().split(/\s+/);
  const a = parts[0]?.[0] || "";
  const b = parts[parts.length - 1]?.[0] || "";
  return (a + b).toUpperCase();
}

// Deterministic avatar color from the palette
const AVATAR_COLORS = ["#5B48FB", "#7363FB", "#9C91FC", "#4B3EC1", "#5B4DD3"];
function avatarColor(name) {
  let h = 0;
  for (const c of name || "·") h = (h * 31 + c.charCodeAt(0)) % 9973;
  return AVATAR_COLORS[h % AVATAR_COLORS.length];
}

// ---- Search synonyms ----
// A typed token matches an entry if the entry's text contains the token itself
// OR any of the token's synonyms. Lets internal shorthand/tickers (e.g. "solv")
// surface everything in a topic area (solar energy) without retagging the data.
const SEARCH_SYNONYMS = {
  solv: ["solar", "photovoltaic", "photovoltaics", "pv", "renewable", "renewables"],
};
function tokenHits(hay, token) {
  if (hay.includes(token)) return true;
  const syns = SEARCH_SYNONYMS[token];
  return syns ? syns.some((s) => hay.includes(s)) : false;
}

function highlight(text, q) {
  if (!q || !text) return text;
  const idx = text.toLowerCase().indexOf(q.toLowerCase());
  if (idx < 0) return text;
  return (
    <>
      {text.slice(0, idx)}
      <mark>{text.slice(idx, idx + q.length)}</mark>
      {text.slice(idx + q.length)}
    </>
  );
}

// ---- Iconography (minimal, hand-drawn SVG primitives only) ----
const Icon = {
  Search: (p) => (
    <svg viewBox="0 0 20 20" width="18" height="18" {...p}>
      <circle cx="9" cy="9" r="6" fill="none" stroke="currentColor" strokeWidth="1.6" />
      <path d="M14 14 L18 18" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  ),
  Check: (p) => (
    <svg viewBox="0 0 16 16" width="14" height="14" {...p}>
      <path d="M3 8.5 L6.5 12 L13 5" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  Warn: (p) => (
    <svg viewBox="0 0 16 16" width="14" height="14" {...p}>
      <circle cx="8" cy="8" r="6.2" fill="none" stroke="currentColor" strokeWidth="1.6" />
      <path d="M8 5 V9" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
      <circle cx="8" cy="11.3" r="0.9" fill="currentColor" />
    </svg>
  ),
  Chevron: (p) => (
    <svg viewBox="0 0 12 12" width="12" height="12" {...p}>
      <path d="M4 3 L8 6 L4 9" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  Arrow: (p) => (
    <svg viewBox="0 0 16 16" width="14" height="14" {...p}>
      <path d="M3 8 H12 M9 5 L12 8 L9 11" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  Slack: (p) => (
    <svg viewBox="0 0 16 16" width="12" height="12" {...p}>
      <rect x="2" y="6.2" width="5.6" height="1.6" rx="0.8" fill="currentColor" />
      <rect x="8.4" y="8.4" width="5.6" height="1.6" rx="0.8" fill="currentColor" />
      <rect x="6.2" y="8.4" width="1.6" height="5.6" rx="0.8" fill="currentColor" />
      <rect x="8.4" y="2" width="1.6" height="5.6" rx="0.8" fill="currentColor" />
    </svg>
  ),
  Filter: (p) => (
    <svg viewBox="0 0 16 16" width="13" height="13" {...p}>
      <path d="M2 3 H14 L10 8 V13 L6 11.5 V8 L2 3 Z" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
    </svg>
  ),
  Close: (p) => (
    <svg viewBox="0 0 12 12" width="12" height="12" {...p}>
      <path d="M3 3 L9 9 M9 3 L3 9" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  ),
  Sparkle: (p) => (
    <svg viewBox="0 0 16 16" width="14" height="14" {...p}>
      <path d="M8 1 L9.2 6.8 L15 8 L9.2 9.2 L8 15 L6.8 9.2 L1 8 L6.8 6.8 Z" fill="currentColor" />
    </svg>
  ),
  Lock: (p) => (
    <svg viewBox="0 0 16 16" width="14" height="14" {...p}>
      <rect x="3.2" y="7" width="9.6" height="6.4" rx="1.4" fill="none" stroke="currentColor" strokeWidth="1.5" />
      <path d="M5.4 7 V5.2 a2.6 2.6 0 0 1 5.2 0 V7" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  ),
  Unlock: (p) => (
    <svg viewBox="0 0 16 16" width="14" height="14" {...p}>
      <rect x="3.2" y="7" width="9.6" height="6.4" rx="1.4" fill="none" stroke="currentColor" strokeWidth="1.5" />
      <path d="M5.4 7 V5.2 a2.6 2.6 0 0 1 5.0 -0.9" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  ),
  Doc: (p) => (
    <svg viewBox="0 0 16 16" width="13" height="13" {...p}>
      <path d="M4 1.5 h5 L12.5 5 v9 a0.6 0.6 0 0 1 -0.6 0.6 H4 a0.6 0.6 0 0 1 -0.6 -0.6 V2.1 A0.6 0.6 0 0 1 4 1.5 Z" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
      <path d="M8.8 1.7 V5 H12.3" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
      <path d="M5.6 8 H10.4 M5.6 10.4 H10.4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  ),
};

// ---- Appendices: documents that source wiki entries ----
// Entries with an `appendix` key point here instead of a Slack thread.
const APPENDICES = {
  A: {
    id: "A",
    title: "CBRE RFP Questionnaire",
    type: "Google Sheet",
    date: "December 2025",
    url: "https://docs.google.com/spreadsheets/d/1WoZDZx2ku00ymlrnOW-B2gEh2rtOiW-lfPzmjlvh4jM/edit?usp=drive_link",
    description: "Vendor due-diligence questionnaire completed for CBRE. Answers were drawn directly from this filled-in response document rather than a Slack discussion.",
  },
  B: {
    id: "B",
    title: "EMEA Chamber of Commerce",
    type: "Document",
    date: "June 2026",
    url: "https://drive.google.com/file/d/1S9MnMNCAkXEpp0U-W9hx2eyltEwARyX_/view?usp=drive_link",
    description: "Chamber of Commerce registration for Zeitview's EMEA entity. The original certificate is in German; an English translation is linked from the entry it backs.",
  },
};

// ---- Top Nav ----
function TopNav({ tab, setTab, editor, setEditor }) {
  const toggleEditor = () => {
    if (editor) {
      setEditor(false);
      try { localStorage.removeItem("wiki_editor"); } catch {}
      return;
    }
    const code = window.prompt("Enter editor passcode to enable editing:");
    if (code == null) return;
    if (code === EDITOR_PASSCODE) {
      setEditor(true);
      try { localStorage.setItem("wiki_editor", "1"); } catch {}
    } else {
      window.alert("Incorrect passcode. Editing stays locked.");
    }
  };
  const exportEdits = async () => {
    let raw = "{}";
    try { raw = localStorage.getItem("wiki_edits") || "{}"; } catch {}
    const obj = JSON.parse(raw || "{}");
    if (!Object.keys(obj).length) {
      window.alert("No saved edits yet. Edit an entry first, then export.");
      return;
    }
    const pretty = JSON.stringify(obj, null, 2);
    // Copy to clipboard so it can be pasted straight back into chat
    try {
      if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(pretty);
      else {
        const ta = document.createElement("textarea");
        ta.value = pretty; ta.style.position = "fixed"; ta.style.opacity = "0";
        document.body.appendChild(ta); ta.select(); document.execCommand("copy");
        document.body.removeChild(ta);
      }
    } catch (_) {}
    // Also download a file as a backup
    try {
      const blob = new Blob([pretty], { type: "application/json" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "wiki-edits.json";
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
    } catch (_) {}
    window.alert("Copied your edits to the clipboard (and downloaded wiki-edits.json). Paste them into the chat so they can be saved permanently.");
  };
  const tabs = [
    { k: "wiki", label: "Wiki" },
    { k: "submissions", label: "Submissions" },
    { k: "corporate", label: "Corporate Info" },
    { k: "compliance-platforms", label: "Compliance Platforms" },
    { k: "insurance", label: "Insurance" },
    { k: "contacts", label: "Contacts" },
    { k: "appendix", label: "Appendix" },
    { k: "changelog", label: "Changelog" },
  ];
  return (
    <div className="topnav">
      <div className="topnav-inner">
        <div className="wordmark" onClick={() => setTab("wiki")} style={{ cursor: "pointer" }}>
          <img className="brand-logo" src={window.ZEITVIEW_LOGO || "assets/zeitview-logo.png"} alt="Zeitview" />
          <div className="brand-sub">Vendor Wiki</div>
        </div>
        <nav className="top-links">
          {tabs.map((t) => (
            <a
              key={t.k}
              className={"top-link " + (tab === t.k ? "active" : "")}
              onClick={() => setTab(t.k)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); setTab(t.k); } }}
            >
              {t.label}
            </a>
          ))}
        </nav>
        <div className="topnav-right">
          <button className="icon-btn" title="Ask AI">
            <Icon.Sparkle />
          </button>
          <button
            className={"icon-btn" + (editor ? " editor-on" : "")}
            onClick={toggleEditor}
            title={editor ? "Editor mode on — click to lock" : "Unlock editing (passcode)"}
            aria-pressed={editor}
          >
            {editor ? <Icon.Unlock /> : <Icon.Lock />}
          </button>
          {editor && (
            <button className="export-edits-btn" onClick={exportEdits} title="Export your saved edits to share/save permanently">
              Export edits
            </button>
          )}
          <div className="avatar-me" title="You">
            <span>ZW</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---- Hero ----
function Hero({ query, setQuery, total, answered, needsReview, authors, onSuggest, heroStyle }) {
  const exampleQueries = [
    "OSHA 300A 2023",
    "void cheque Canada",
    "Avetta professional liability",
    "Coupa account",
    "SOC 2",
  ];
  return (
    <section className={"hero hero-" + heroStyle}>
      <div className="hero-shell">
        <div className="hero-eyebrow">
          <span className="pulse-dot" /> Live from <b>#vendor-management</b> · {total} entries indexed
        </div>
        <h1 className="hero-title">
          Has this vendor question<br/>
          <span className="hero-emph">been answered before?</span>
        </h1>
        <p className="hero-sub">
          Internal Q&A for vendor onboarding, compliance, and RFP responses. Search past threads before you retype the answer.
        </p>
        <SearchBar query={query} setQuery={setQuery} />
        <div className="hero-examples">
          <span className="ex-label">Try</span>
          {exampleQueries.map((q) => (
            <button key={q} className="ex-chip" onClick={() => onSuggest(q)}>
              {q}
            </button>
          ))}
        </div>
        <div className="hero-stats">
          <div className="stat"><b>{answered}</b><span>answered</span></div>
          <div className="stat"><b>{needsReview}</b><span>needs review</span></div>
          <div className="stat"><b>{authors}</b><span>authors</span></div>
          <div className="stat"><b>2d</b><span>since last update</span></div>
        </div>
      </div>
    </section>
  );
}

function SearchBar({ query, setQuery }) {
  const ref = useRef(null);
  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        ref.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);
  return (
    <div className="search-wrap">
      <div className="search">
        <span className="search-icon"><Icon.Search /></span>
        <input
          ref={ref}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search questions, answers, or keywords…"
          aria-label="Search the wiki"
        />
        {query && (
          <button className="search-clear" onClick={() => setQuery("")} aria-label="Clear">
            <Icon.Close />
          </button>
        )}
        <span className="kbd">⌘K</span>
      </div>
    </div>
  );
}

// ---- Sidebar ----
function Sidebar({ data, activeCat, activeSub, setCat, setSub, mobileOpen, onCloseMobile }) {
  const tree = useMemo(() => {
    const t = {};
    for (const cat of CATEGORIES_ORDER) t[cat] = { total: 0, subs: {} };
    for (const d of data) {
      if (!t[d.category]) t[d.category] = { total: 0, subs: {} };
      t[d.category].total++;
      t[d.category].subs[d.subcategory] = (t[d.category].subs[d.subcategory] || 0) + 1;
    }
    return t;
  }, [data]);

  const [open, setOpen] = useState(() => {
    const o = {};
    for (const c of CATEGORIES_ORDER) o[c] = true;
    return o;
  });

  const toggle = (c) => setOpen((s) => ({ ...s, [c]: !s[c] }));

  return (
    <>
    <div className={"sidebar-scrim " + (mobileOpen ? "open" : "")} onClick={onCloseMobile} />
    <aside className={"sidebar " + (mobileOpen ? "sidebar-mobile-open" : "")}>
      <div className="side-head">
        <div className="side-head-row">
          <div className="side-label">BROWSE</div>
          <button className="side-close" onClick={onCloseMobile} aria-label="Close"><Icon.Close /></button>
        </div>
        <button
          className={"all-btn " + (!activeCat ? "active" : "")}
          onClick={() => { setCat(null); setSub(null); }}
        >
          <span>All entries</span>
          <span className="count">{data.length}</span>
        </button>
      </div>

      <nav className="side-nav">
        {CATEGORIES_ORDER.map((cat) => {
          const node = tree[cat];
          const isActive = activeCat === cat;
          const isOpen = open[cat];
          return (
            <div key={cat} className={"cat " + (isActive ? "active-cat" : "")}>
              <button
                className={"cat-row " + (isActive && !activeSub ? "active" : "")}
                onClick={() => {
                  if (!isOpen) toggle(cat);
                  setCat(cat); setSub(null);
                }}
              >
                <span
                  className={"caret " + (isOpen ? "open" : "")}
                  onClick={(e) => { e.stopPropagation(); toggle(cat); }}
                  role="button"
                >
                  <Icon.Chevron />
                </span>
                <span className="cat-name">{cat}</span>
                <span className="count">{node?.total || 0}</span>
              </button>
              {isOpen && (
                <div className="subs">
                  {Object.entries(node?.subs || {}).map(([sub, n]) => (
                    <button
                      key={sub}
                      className={"sub-row " + (activeCat === cat && activeSub === sub ? "active" : "")}
                      onClick={() => { setCat(cat); setSub(sub); }}
                    >
                      <span className="sub-name">{sub}</span>
                      <span className="count">{n}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      <div className="side-footer">
        <div className="card-mini">
          <div className="mini-title">Can't find it?</div>
          <div className="mini-body">Post in #vendor-management and tag @vendor-wiki to add the answer back here.</div>
          <button className="mini-cta">Open Slack <Icon.Arrow /></button>
        </div>
      </div>
    </aside>
    </>
  );
}

// ---- Main content: controls + list ----
function StatusBadge({ status }) {
  if (status === "needs-review") {
    return (
      <span className="badge badge-warn">
        <Icon.Warn /> Needs review
      </span>
    );
  }
  return (
    <span className="badge badge-ok">
      <Icon.Check /> Answered
    </span>
  );
}

function Avatar({ name, size = 26 }) {
  return (
    <span
      className="avatar"
      style={{
        background: avatarColor(name),
        width: size,
        height: size,
        fontSize: Math.round(size * 0.42),
      }}
      title={name}
    >
      {initials(name)}
    </span>
  );
}

function EntryCard({ entry, query, onOpen, showReplies, onNav }) {
  const answerPlain = plainText(entry.answer || "");
  const hasLink = /\[[^\]]+\]\s*\((?:https?|file|doc):\/\//.test(entry.answer || "")
    || /<(?:https?|file|doc):\/\//.test(entry.answer || "");
  const answerShort = answerPlain.slice(0, 260);
  const truncated = answerPlain.length > 260;
  return (
    <article className="entry-card" onClick={() => onOpen(entry)} tabIndex={0}
      onKeyDown={(e)=>{ if(e.key==='Enter') onOpen(entry); }}>
      <div className="entry-top">
        <div className="crumb">
          <button type="button" className="crumb-link" title={"Filter by " + entry.category}
            onClick={(e) => { e.stopPropagation(); onNav?.(entry.category, null); }}>{entry.category}</button>
          <span className="crumb-sep">›</span>
          <button type="button" className="crumb-link crumb-sub" title={"Filter by " + entry.subcategory}
            onClick={(e) => { e.stopPropagation(); onNav?.(entry.category, entry.subcategory); }}>{entry.subcategory}</button>
        </div>
        <StatusBadge status={entry.status} />
      </div>
      <h3 className="q">{highlight(entry.question, query)}</h3>
      <p className="a">
        {hasLink ? (
          <AnswerText text={entry.answer} query={query} stop={true} />
        ) : (
          <>
            {highlight(answerShort, query)}
            {truncated ? "… " : " "}
            {truncated && <span className="read-more">Read more</span>}
          </>
        )}
      </p>
      <div className="entry-foot">
        <div className="foot-left">
          {entry.appendix && APPENDICES[entry.appendix] ? (
            <span className="appendix-attr">
              <span className="appendix-chip"><Icon.Doc /> Appendix {entry.appendix}</span>
              <span className="dot">·</span>
              <span className="date">{entry.date || "Undated"}</span>
            </span>
          ) : (
            <>
              <Avatar name={entry.author} />
              <span className="author">{entry.author || "—"}</span>
              <span className="dot">·</span>
              <span className="date">{entry.date || "Undated"}</span>
              {showReplies && entry.replies > 0 && (
                <>
                  <span className="dot">·</span>
                  <span className="replies">{entry.replies} {entry.replies === 1 ? "reply" : "replies"}</span>
                </>
              )}
            </>
          )}
        </div>
        {entry.appendix && APPENDICES[entry.appendix] ? (
          <a
            className="slack-link appendix-link"
            href={APPENDICES[entry.appendix].url}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e)=>{ e.stopPropagation(); }}
          >
            <Icon.Doc /> Open Appendix {entry.appendix} <Icon.Arrow />
          </a>
        ) : entry.slack ? (
          <a
            className="slack-link"
            href={entry.slack}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e)=>{ e.stopPropagation(); }}
          >
            <Icon.Slack /> View Slack thread <Icon.Arrow />
          </a>
        ) : entry.source ? (
          <span className="source-tag">{entry.source}</span>
        ) : null}
      </div>
    </article>
  );
}

function Main({ data, query, setQuery, activeCat, activeSub, setCat, setSub, tweaks, openEntry, setOpenEntry, onSave, editor, onOpenBrowse }) {
  const [status, setStatus] = useState("all"); // all | answered | needs-review
  const [sort, setSort] = useState("newest");
  const [recentOnly, setRecentOnly] = useState(false);

  const filtered = useMemo(() => {
    let list = data.slice();
    if (activeCat) list = list.filter((d) => d.category === activeCat);
    if (activeSub) list = list.filter((d) => d.subcategory === activeSub);
    if (status !== "all") list = list.filter((d) => d.status === status);
    if (recentOnly) {
      const cutoff = parseDate("Aug 01, 2025");
      list = list.filter((d) => parseDate(d.date) >= cutoff);
    }
    if (query.trim()) {
      const q = query.toLowerCase();
      const tokens = q.split(/\s+/).filter(Boolean);
      list = list.filter((d) => {
        const hay = (
          (d.question || "") + " " +
          (d.answer || "") + " " +
          (d.category || "") + " " +
          (d.subcategory || "") + " " +
          (d.author || "") + " " +
          (d.keywords || "")
        ).toLowerCase();
        // Match the full phrase OR every individual word (so "void cheque Canada"
        // still finds "void cheque for Canada"). Falls back to phrase match for
        // single-word queries.
        return hay.includes(q) || tokens.every((t) => tokenHits(hay, t));
      });
    }
    list.sort((a, b) => {
      if (sort === "newest") return parseDate(b.date) - parseDate(a.date);
      if (sort === "oldest") return parseDate(a.date) - parseDate(b.date);
      if (sort === "category") return (a.category + a.subcategory).localeCompare(b.category + b.subcategory);
      return 0;
    });
    return list;
  }, [data, activeCat, activeSub, status, recentOnly, query, sort]);

  const totalCounts = useMemo(() => {
    let base = data;
    if (activeCat) base = base.filter((d) => d.category === activeCat);
    if (activeSub) base = base.filter((d) => d.subcategory === activeSub);
    return {
      all: base.length,
      answered: base.filter((d) => d.status === "answered").length,
      review: base.filter((d) => d.status === "needs-review").length,
    };
  }, [data, activeCat, activeSub]);

  // Keyboard nav through cards
  const listRef = useRef(null);
  useEffect(() => {
    const onKey = (e) => {
      if (document.activeElement?.tagName === "INPUT") return;
      if (e.key === "j" || e.key === "k") {
        const cards = [...(listRef.current?.querySelectorAll(".entry-card") || [])];
        const idx = cards.indexOf(document.activeElement);
        let next = e.key === "j" ? idx + 1 : idx - 1;
        if (idx < 0) next = 0;
        next = Math.max(0, Math.min(cards.length - 1, next));
        cards[next]?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <main className="main">
      <header className="main-head">
        <div className="main-head-left">
          <button type="button" className="browse-toggle" onClick={onOpenBrowse}>
            <Icon.Filter /> Browse categories
          </button>
          <div className="breadcrumb">
            <span className="crumb-home" onClick={() => { setCat(null); setSub(null); }}>Wiki</span>
            {activeCat && <> <span className="crumb-sep">›</span> <span className="crumb-mid" onClick={()=>setSub(null)}>{activeCat}</span></>}
            {activeSub && <> <span className="crumb-sep">›</span> <span className="crumb-cur">{activeSub}</span></>}
            {!activeCat && <> <span className="crumb-sep">›</span> <span className="crumb-cur">All entries</span></>}
          </div>
          <h2 className="main-title">
            {activeSub || activeCat || "All entries"}
          </h2>
          <div className="main-meta">
            {filtered.length} of {totalCounts.all} entries
            {query && <> matching "<b>{query}</b>"</>}
          </div>
        </div>
        <div className="main-head-right">
          <button className="ghost-btn">
            <Icon.Filter /> More filters
          </button>
          <button className="primary-btn">
            + New entry
          </button>
        </div>
      </header>

      <div className="controls">
        <div className="chips">
          {[
            { k: "all", label: "All", count: totalCounts.all },
            { k: "answered", label: "Answered", count: totalCounts.answered, dot: "ok" },
            { k: "needs-review", label: "Needs review", count: totalCounts.review, dot: "warn" },
          ].map((c) => (
            <button
              key={c.k}
              className={"chip " + (status === c.k ? "chip-active" : "")}
              onClick={() => setStatus(c.k)}
            >
              {c.dot && <span className={"chip-dot " + c.dot} />}
              {c.label}
              <span className="chip-count">{c.count}</span>
            </button>
          ))}
        </div>
        <div className="controls-right">
          <label className="toggle">
            <input type="checkbox" checked={recentOnly} onChange={(e) => setRecentOnly(e.target.checked)} />
            <span className="toggle-slider" />
            <span className="toggle-label">Recent (last 90 days)</span>
          </label>
          <div className="sort">
            <span className="sort-label">Sort</span>
            <select value={sort} onChange={(e) => setSort(e.target.value)}>
              <option value="newest">Newest first</option>
              <option value="oldest">Oldest first</option>
              <option value="category">By category</option>
            </select>
          </div>
        </div>
      </div>

      <div className="entries" ref={listRef}>
        {filtered.length === 0 && <EmptyState query={query} onReset={() => { setQuery(""); setCat(null); setSub(null); setStatus("all"); setRecentOnly(false); }} />}
        {filtered.map((e) => (
          <EntryCard key={e.id} entry={e} query={query} onOpen={setOpenEntry} showReplies={tweaks.showReplyCount}
            onNav={(cat, sub) => { setCat(cat); setSub(sub); }} />
        ))}
      </div>

      {openEntry && <EntryModal entry={openEntry} onClose={() => setOpenEntry(null)} onSave={onSave} editor={editor}
        onNav={(cat, sub) => { setCat(cat); setSub(sub); setOpenEntry(null); }} />}
    </main>
  );
}

function EmptyState({ query, onReset }) {
  return (
    <div className="empty">
      <div className="empty-illus" aria-hidden>
        <svg viewBox="0 0 160 110" width="180" height="124">
          <defs>
            <linearGradient id="gf" x1="0" x2="1" y1="0" y2="1">
              <stop offset="0" stopColor="#EFECFF" />
              <stop offset="1" stopColor="#CDC7FE" />
            </linearGradient>
          </defs>
          <rect x="8" y="16" width="144" height="86" rx="10" fill="url(#gf)" />
          <rect x="20" y="30" width="80" height="8" rx="4" fill="white" />
          <rect x="20" y="46" width="110" height="6" rx="3" fill="white" opacity="0.8" />
          <rect x="20" y="58" width="90" height="6" rx="3" fill="white" opacity="0.8" />
          <circle cx="118" cy="76" r="14" fill="white" />
          <circle cx="118" cy="76" r="9" fill="none" stroke="#5B48FB" strokeWidth="2" />
          <path d="M124 82 L130 88" stroke="#5B48FB" strokeWidth="2.2" strokeLinecap="round" />
        </svg>
      </div>
      <h3>No matches</h3>
      <p>
        {query
          ? <>No entries contain "<b>{query}</b>". Try broader terms, or browse categories in the sidebar.</>
          : <>No entries match these filters. Try clearing them.</>}
      </p>
      <button className="primary-btn" onClick={onReset}>Reset filters</button>
    </div>
  );
}

// Renders answer text with clickable links. Forgiving about format — supports
// bare URLs, [label](url) (with or without a space), and Slack-style <url|label>.
// Opens an embedded PDF in an in-app overlay (no new tab / no popup blocking).
function showDocOverlay(blobUrl, name) {
  const existing = document.getElementById("doc-overlay");
  if (existing) existing.remove();
  const ov = document.createElement("div");
  ov.id = "doc-overlay";
  ov.setAttribute("style", [
    "position:fixed", "inset:0", "z-index:9999",
    "background:rgba(20,18,30,0.72)", "backdrop-filter:blur(4px)",
    "display:flex", "flex-direction:column", "padding:24px",
  ].join(";"));
  const bar = document.createElement("div");
  bar.setAttribute("style", "display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px 14px;background:#fff;border-radius:10px 10px 0 0;font:600 14px/1.2 system-ui,sans-serif;color:#1c1b22");
  const title = document.createElement("span");
  title.textContent = name || "Document";
  const actions = document.createElement("div");
  actions.setAttribute("style", "display:flex;align-items:center;gap:8px");
  const dl = document.createElement("a");
  dl.textContent = "Download";
  dl.href = blobUrl; dl.download = name || "document.pdf";
  dl.setAttribute("style", "text-decoration:none;color:#6d5ae6;font-weight:600;padding:6px 12px;border:1px solid #e3e0f0;border-radius:7px");
  const close = document.createElement("button");
  close.textContent = "✕ Close";
  close.setAttribute("style", "cursor:pointer;border:none;background:#6d5ae6;color:#fff;font-weight:600;padding:7px 14px;border-radius:7px");
  close.onclick = () => ov.remove();
  actions.appendChild(dl); actions.appendChild(close);
  bar.appendChild(title); bar.appendChild(actions);
  const frame = document.createElement("iframe");
  frame.src = blobUrl;
  frame.setAttribute("style", "flex:1;width:100%;border:none;border-radius:0 0 10px 10px;background:#fff");
  ov.appendChild(bar); ov.appendChild(frame);
  ov.addEventListener("click", (e) => { if (e.target === ov) ov.remove(); });
  document.addEventListener("keydown", function esc(e){ if(e.key==="Escape"){ ov.remove(); document.removeEventListener("keydown", esc);} });
  document.body.appendChild(ov);
}

// Strip markdown/link syntax down to readable text for card previews:
//  [label](url) -> label   ·   <url|label> -> label   ·   <url> -> url
function plainText(str) {
  return String(str || "")
    .replace(/\[([^\]]+)\]\s*\((?:https?|file|doc):\/\/[^\s)]+\)/g, "$1")
    .replace(/<(?:https?|file|doc):\/\/[^\s|>]+\|([^>]+)>/g, "$1")
    .replace(/<((?:https?|file|doc):\/\/[^\s|>]+)>/g, "$1");
}

function AnswerText({ text, query, stop }) {
  const str = String(text || "");
  if (!str) return "—";
  // Apply search highlighting to plain-text segments between links.
  const pushText = (seg) => {
    if (!seg) return;
    if (query) nodes.push(<React.Fragment key={key++}>{highlight(seg, query)}</React.Fragment>);
    else nodes.push(seg);
  };
  const re = /\[([^\]]+)\]\s*\(((?:https?|file|doc):\/\/[^\s)]+)\)|<((?:https?|file|doc):\/\/[^\s|>]+)(?:\|([^>]+))?>|((?:https?|file):\/\/[^\s<]+)/g;
  const nodes = [];
  let last = 0, m, key = 0;
  while ((m = re.exec(str)) !== null) {
    if (m.index > last) pushText(str.slice(last, m.index));
    let label, url, trailing = "";
    if (m[2]) { label = m[1]; url = m[2]; }
    else if (m[3]) { url = m[3]; label = m[4] || m[3]; }
    else {
      url = m[5]; label = m[5];
      const t = url.match(/[).,;:!?]+$/);
      if (t) { trailing = t[0]; url = url.slice(0, -trailing.length); label = url; }
    }
    // Resolve doc:// links to the embedded PDF (opened as an in-memory blob).
    if (url.indexOf("doc://") === 0) {
      const id = url.slice(6);
      const names = {
        "bahamas-nib": "Bahamas NIB Registration.pdf",
        "wsib-clearance": "WSIB Clearance Certificate.pdf",
        "zeitview-emr-signed": "Zeitview EMR Letter (signed).pdf",
        "emr-marsh-mclennan": "EMR Letter - Marsh McLennan.pdf",
        "compline-emr-history": "Compline Riskscreen - EMR History.pdf",
        "employer-stamp-exception": "Employer Stamp Exception Letter.pdf",
      };
      const resolved = (typeof window !== "undefined" && window.resolveDoc) ? window.resolveDoc(id) : null;
      nodes.push(
        <a
          key={key++}
          className="answer-link"
          href={resolved || "#"}
          download={names[id] || (id + ".pdf")}
          onClick={(e) => {
            e.preventDefault();
            if (stop) e.stopPropagation();
            const u = window.resolveDoc && window.resolveDoc(id);
            if (!u) { alert("Document not available."); return; }
            showDocOverlay(u, names[id] || (id + ".pdf"));
          }}
        >
          {query ? highlight(label, query) : label}
        </a>
      );
      if (trailing) nodes.push(trailing);
      last = re.lastIndex;
      continue;
    }
    nodes.push(
      <a
        key={key++}
        className="answer-link"
        href={url}
        target="_blank"
        rel="noopener noreferrer"
        onClick={stop ? (e) => e.stopPropagation() : undefined}
      >
        {query ? highlight(label, query) : label}
      </a>
    );
    if (trailing) nodes.push(trailing);
    last = re.lastIndex;
  }
  if (last < str.length) pushText(str.slice(last));
  return nodes.length ? nodes : str;
}

function EntryModal({ entry, onClose, onSave, editor, onNav }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(entry.answer || "");
  const [answer, setAnswer] = useState(entry.answer || "");
  const [copied, setCopied] = useState(false);
  const taRef = useRef(null);

  // Reset local state when a different entry is opened
  useEffect(() => {
    setAnswer(entry.answer || "");
    setDraft(entry.answer || "");
    setEditing(false);
    setCopied(false);
  }, [entry.id]);

  useEffect(() => {
    const k = (e) => e.key === "Escape" && (editing ? setEditing(false) : onClose());
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [onClose, editing]);

  useEffect(() => {
    if (editing && taRef.current) { taRef.current.focus(); }
  }, [editing]);

  // If editor mode is locked while a draft is open, drop out of edit mode.
  useEffect(() => {
    if (!editor) setEditing(false);
  }, [editor]);

  const copyAnswer = async () => {
    const text = answer || "";
    let ok = false;
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
        ok = true;
      }
    } catch (_) { /* fall through to legacy path */ }
    if (!ok) {
      try {
        const ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.select();
        ok = document.execCommand("copy");
        document.body.removeChild(ta);
      } catch (_) { ok = false; }
    }
    if (ok) {
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    }
  };

  const saveDraft = () => {
    const v = draft.trim();
    setAnswer(v);
    onSave?.(entry.id, { answer: v });
    setEditing(false);
  };

  return (
    <div className="modal-scrim" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <div className="crumb">
            <button type="button" className={"crumb-link" + (onNav ? "" : " crumb-static")} title={onNav ? "Filter by " + entry.category : undefined}
              onClick={() => onNav?.(entry.category, null)}>{entry.category}</button>
            <span className="crumb-sep">›</span>
            <button type="button" className={"crumb-link crumb-sub" + (onNav ? "" : " crumb-static")} title={onNav ? "Filter by " + entry.subcategory : undefined}
              onClick={() => onNav?.(entry.category, entry.subcategory)}>{entry.subcategory}</button>
          </div>
          <div className="modal-head-right">
            <StatusBadge status={entry.status} />
            <button className="icon-btn" onClick={onClose} aria-label="Close"><Icon.Close /></button>
          </div>
        </div>
        <h2 className="modal-q">{entry.question}</h2>
        {entry.appendix && APPENDICES[entry.appendix] ? (
          <div className="modal-byline">
            <div className="appendix-avatar"><Icon.Doc /></div>
            <div>
              <div className="modal-author">Appendix {entry.appendix} — {APPENDICES[entry.appendix].title}</div>
              <div className="modal-date">Sourced from document · {entry.date}</div>
            </div>
          </div>
        ) : (
          <div className="modal-byline">
            <Avatar name={entry.author} size={30} />
            <div>
              <div className="modal-author">{entry.author || "—"}</div>
              <div className="modal-date">Asked {entry.date}</div>
            </div>
            {entry.replies > 0 && (
              <div className="replies-pill">{entry.replies} {entry.replies === 1 ? "reply" : "replies"} in thread</div>
            )}
          </div>
        )}
        <div className="modal-section-label">Answer</div>
        {editing ? (
          <textarea
            ref={taRef}
            className="modal-answer-edit"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="Write the answer for this entry… Paste a full link (https://…) and it becomes clickable. For a labelled link use [Certificate of Incorporation](https://…)"
            rows={5}
          />
        ) : (
          <div className={"modal-answer " + (entry.status === "needs-review" ? "answer-review" : "")}>
            {entry.status === "needs-review" && (
              <div className="review-head">
                <Icon.Warn /> This item is still open — needs follow-up in Slack.
              </div>
            )}
            <p><AnswerText text={answer} /></p>
          </div>
        )}
        <div className="modal-actions">
          {editing ? (
            <>
              <button className="primary-btn" onClick={saveDraft}>Save changes</button>
              <button className="ghost-btn" onClick={() => { setDraft(answer); setEditing(false); }}>Cancel</button>
            </>
          ) : (
            <>
              {entry.appendix && APPENDICES[entry.appendix] ? (
                <a
                  className="primary-btn"
                  href={APPENDICES[entry.appendix].url}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{ textDecoration: "none" }}
                >
                  <Icon.Doc /> Open Appendix {entry.appendix}
                </a>
              ) : (
                <a
                  className="primary-btn"
                  href={entry.slack || "#"}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{ textDecoration: "none", display: entry.slack ? "" : "none" }}
                  onClick={(e)=>{ if(!entry.slack) e.preventDefault(); }}
                >
                  <Icon.Slack /> Open Slack thread
                </a>
              )}
              {!entry.slack && !entry.appendix && entry.source && (
                <span className="modal-source-tag">{entry.source}</span>
              )}
              <button className="ghost-btn" onClick={copyAnswer}>{copied ? "Copied ✓" : "Copy answer"}</button>
              {editor && (
                <button className="ghost-btn" onClick={() => { setDraft(answer); setEditing(true); }}>Edit entry</button>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ---- Tweaks panel ----
function TweaksPanel({ tweaks, setTweaks, visible, onClose }) {
  if (!visible) return null;
  const persist = (patch) => {
    window.parent.postMessage({ type: "__edit_mode_set_keys", edits: patch }, "*");
  };
  const update = (patch) => {
    setTweaks((t) => ({ ...t, ...patch }));
    persist(patch);
  };
  return (
    <div className="tweaks">
      <div className="tweaks-head">
        <b>Tweaks</b>
        <button className="icon-btn" onClick={onClose}><Icon.Close /></button>
      </div>
      <label className="tweak-row">
        <span>Primary color</span>
        <input type="color" value={tweaks.primaryColor} onChange={(e) => update({ primaryColor: e.target.value })} />
      </label>
      <label className="tweak-row">
        <span>Accent tint</span>
        <input type="color" value={tweaks.accentTint} onChange={(e) => update({ accentTint: e.target.value })} />
      </label>
      <div className="tweak-row">
        <span>Hero style</span>
        <div className="seg">
          {["gradient", "flat", "grid"].map((s) => (
            <button key={s} className={tweaks.heroStyle === s ? "seg-on" : ""} onClick={() => update({ heroStyle: s })}>{s}</button>
          ))}
        </div>
      </div>
      <div className="tweak-row">
        <span>Card density</span>
        <div className="seg">
          {["compact", "comfortable", "spacious"].map((s) => (
            <button key={s} className={tweaks.cardDensity === s ? "seg-on" : ""} onClick={() => update({ cardDensity: s })}>{s}</button>
          ))}
        </div>
      </div>
      <label className="tweak-row">
        <span>Show reply count</span>
        <input type="checkbox" checked={tweaks.showReplyCount} onChange={(e) => update({ showReplyCount: e.target.checked })} />
      </label>
    </div>
  );
}

// ---- Submissions view ----
function SubmissionsView({ data, setOpenEntry, setTab }) {
  const [form, setForm] = useState({ question: "", category: CATEGORIES_ORDER[0], subcategory: "", context: "" });
  const [submitted, setSubmitted] = useState(false);
  const reviewItems = useMemo(
    () => data.filter((d) => d.status === "needs-review").sort((a, b) => parseDate(b.date) - parseDate(a.date)),
    [data]
  );
  const subOptions = useMemo(() => {
    const set = new Set();
    for (const d of data) if (d.category === form.category) set.add(d.subcategory);
    return [...set];
  }, [data, form.category]);

  const submit = (e) => {
    e.preventDefault();
    if (!form.question.trim()) return;
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setForm({ question: "", category: CATEGORIES_ORDER[0], subcategory: "", context: "" });
    }, 2400);
  };

  return (
    <div className="page page-submissions">
      <div className="page-head">
        <div className="page-eyebrow">SUBMISSIONS</div>
        <h1 className="page-title">Submit a new vendor question</h1>
        <p className="page-sub">Post here and it lands in <b>#vendor-management</b> for triage. Answered threads get folded back into the wiki within a day.</p>
      </div>
      <div className="page-grid">
        <form className="submit-card" onSubmit={submit}>
          <div className="field">
            <label>Your question</label>
            <textarea
              rows={3}
              value={form.question}
              onChange={(e) => setForm((f) => ({ ...f, question: e.target.value }))}
              placeholder="e.g. Do we have a current SOC 2 Type II report we can share with prospects?"
            />
          </div>
          <div className="field-row" style={{ display: "grid", gridTemplateColumns: "minmax(0, 1fr) minmax(0, 1fr)", gap: 14 }}>
            <div className="field" style={{ minWidth: 0 }}>
              <label>Category</label>
              <select style={{ width: "100%", minWidth: 0, maxWidth: "100%", boxSizing: "border-box", textOverflow: "ellipsis" }} value={form.category} onChange={(e) => setForm((f) => ({ ...f, category: e.target.value, subcategory: "" }))}>
                {CATEGORIES_ORDER.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="field" style={{ minWidth: 0 }}>
              <label>Subcategory</label>
              <select style={{ width: "100%", minWidth: 0, maxWidth: "100%", boxSizing: "border-box", textOverflow: "ellipsis" }} value={form.subcategory} onChange={(e) => setForm((f) => ({ ...f, subcategory: e.target.value }))}>
                <option value="">— Optional —</option>
                {subOptions.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>
          <div className="field">
            <label>Context <span className="optional">(optional)</span></label>
            <textarea
              rows={3}
              value={form.context}
              onChange={(e) => setForm((f) => ({ ...f, context: e.target.value }))}
              placeholder="Link the vendor portal, attach screenshots, paste the exact text you're being asked for…"
            />
          </div>
          <div className="submit-foot">
            <div className="submit-hint">Posts as <b>You · #vendor-management</b></div>
            <button type="submit" className="primary-btn" disabled={!form.question.trim() || submitted}>
              {submitted ? <><Icon.Check /> Posted to Slack</> : <>Post question <Icon.Arrow /></>}
            </button>
          </div>
        </form>

        <aside className="open-queue">
          <div className="queue-head">
            <h3>Open questions</h3>
            <span className="queue-count">{reviewItems.length}</span>
          </div>
          <p className="queue-sub">Still being chased down. Click to read the thread.</p>
          <div className="queue-list">
            {reviewItems.slice(0, 12).map((d) => (
              <button key={d.id} className="queue-item" onClick={() => setOpenEntry(d)}>
                <div className="queue-q">{d.question}</div>
                <div className="queue-meta">
                  <Avatar name={d.author} size={20} />
                  <span>{d.author}</span>
                  <span className="dot">·</span>
                  <span>{d.date}</span>
                  <span className="dot">·</span>
                  <span className="queue-cat">{CATEGORY_SHORT[d.category] || d.category}</span>
                </div>
              </button>
            ))}
            {reviewItems.length === 0 && <div className="queue-empty">Inbox zero. Nothing currently open.</div>}
          </div>
          <button className="ghost-btn queue-jump" onClick={() => setTab("wiki")}>Browse all entries <Icon.Arrow /></button>
        </aside>
      </div>
    </div>
  );
}

// ---- Contacts view ----
const INACTIVE_AUTHORS = new Set([
  "Andrew Watt",
  "Bill Stafford",
  "Chantelle Gubert",
  "Jimmy Carter",
  "Ryan Waring",
  "Skyler Jelly",
  "Melissa Karner",
  "Scott Duffin",
  "Erick Lindberg",
]);
// Explicit position titles for the contacts directory (overrides the inferred category).
const CONTACT_TITLES = {
  "Amanda Zee": "Client Operations Manager, Solar",
  "Anthony Steele": "Account Manager, Solar",
  "Ben Spears": "Account Manager, Solar",
  "Brent Chase": "Sales, Solar",
  "Catherine Crudup": "Global Payroll & Benefits Manager",
  "Cheryl Snowdon": "Revenue Operations",
  "Chris Wells": "Sr. Manager of Geospatial Operations",
  "Cristina Bohorquez": "Account Manager Wind and Solar, EU",
  "Daryl Watkins": "VP, Global Enterprise Solutions",
  "Graeme Clancy": "Senior Manager, Solar Flight Operations Global",
  "Kiley Sullivan": "Customer Success Manager, Wind",
  "Lindi Theron": "Operational Coordinator, Europe (Berlin)",
  "Lira Park": "VP, Utility Sales",
  "Marcelo Neves Mello": "Account Coordinator, LatAm",
  "Merritt Pearson": "Wind Operations Director",
  "Mira-belle Ajayi": "Customer Success Coordinator",
  "Nick Ferranti": "Director of Account Management",
  "Sami Azaroual": "Ops Europe, Spain (Barcelona)",
  "Scott Johnson": "VP, Customer Solutions & Revenue Operations",
  "Sofía Osorio": "EMEA Ops Lead",
};
// Authors that are documents/sheets or merged/ambiguous handles, not single people — excluded from the Contacts directory.
const NON_PERSON_AUTHORS = new Set([
  "CBRE RFP 2025",
  "ZV Corporate Info",
  "EMEA Vendor Qualification",
  "EMEA Vendor Qualification Sheet",
  "Alyssa Hilgen / Jimmy Carter",
  "Marsh & McLennan (Alyssa Hilgen)",
]);


// ---- Contact departments + direct reach-out ----
const EMAIL_DOMAIN = "zeitview.com"; // emails default to first.last@EMAIL_DOMAIN
const CONTACT_EMAILS = {}; // overrides, e.g. { "Name Here": "name@company.com" }
const CONTACT_PHONES = {}; // optional, e.g. { "Name Here": "+1 555 010 0100" }
const DEPT_ORDER = ["Leadership", "Sales & Account Management", "Customer Success", "Operations", "Finance & Revenue Ops", "Compliance & Legal", "Other contributors", "Former staff"];
function contactEmail(name) {
  if (CONTACT_EMAILS[name]) return CONTACT_EMAILS[name];
  const p = name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z\s-]/g, "").trim().split(/\s+/);
  return p.length > 1 ? p[0] + "." + p[p.length - 1] + "@" + EMAIL_DOMAIN : p[0] + "@" + EMAIL_DOMAIN;
}
function contactDept(c) {
  if (c.inactive) return "Former staff";
  const t = c.title || "";
  if (/\b(VP|Director|Head|Chief)\b/i.test(t)) return "Leadership";
  if (/payroll|benefits|finance|revenue|billing|accounting/i.test(t)) return "Finance & Revenue Ops";
  if (/operation|ops\b|flight|geospatial/i.test(t)) return "Operations";
  if (/customer success|coordinator/i.test(t)) return "Customer Success";
  if (/account|sales/i.test(t)) return "Sales & Account Management";
  const top = c.topCategory || "";
  if (/finance/i.test(top)) return "Finance & Revenue Ops";
  if (/legal|safety|compliance|insurance/i.test(top)) return "Compliance & Legal";
  return "Other contributors";
}
function ContactsView({ data, setOpenEntry, setQuery, setTab }) {
  const [filter, setFilter] = useState("");
  const [showInactive, setShowInactive] = useState(true);
  const [dept, setDept] = useState("All");
  const [copied, setCopied] = useState(null);
  const contacts = useMemo(() => {
    const m = new Map();
    for (const d of data) {
      if (d.appendix) continue;
      if (!d.author) continue;
      if (NON_PERSON_AUTHORS.has(d.author)) continue;
      if (!m.has(d.author)) m.set(d.author, { name: d.author, entries: [], categories: new Set(), subs: {} });
      const c = m.get(d.author);
      c.entries.push(d);
      c.categories.add(d.category);
      if (d.subcategory) c.subs[d.subcategory] = (c.subs[d.subcategory] || 0) + 1;
    }
    return [...m.values()]
      .map((c) => {
        const catCount = {};
        c.entries.forEach((e) => (catCount[e.category] = (catCount[e.category] || 0) + 1));
        const o = {
          ...c,
          count: c.entries.length,
          latest: c.entries.reduce((acc, e) => Math.max(acc, parseDate(e.date)), 0),
          topCategory: Object.entries(catCount).sort((a, b) => b[1] - a[1])[0][0],
          topics: Object.entries(c.subs).sort((a, b) => b[1] - a[1]).slice(0, 4).map((x) => x[0]),
          title: CONTACT_TITLES[c.name] || null,
          inactive: INACTIVE_AUTHORS.has(c.name),
        };
        o.dept = contactDept(o);
        o.email = contactEmail(c.name);
        o.phone = CONTACT_PHONES[c.name] || null;
        return o;
      })
      .sort((a, b) => b.count - a.count);
  }, [data]);

  const q = filter.toLowerCase();
  const filtered = contacts.filter((c) => {
    if (!showInactive && c.inactive) return false;
    if (dept !== "All" && c.dept !== dept) return false;
    if (!q) return true;
    return c.name.toLowerCase().includes(q) || (c.title || "").toLowerCase().includes(q) || c.topics.some((t) => t.toLowerCase().includes(q)) || [...c.categories].some((t) => t.toLowerCase().includes(q));
  });
  const activeCount = contacts.filter((c) => !c.inactive).length;
  const inactiveCount = contacts.length - activeCount;
  const deptCounts = {};
  contacts.forEach((c) => { if (showInactive || !c.inactive) deptCounts[c.dept] = (deptCounts[c.dept] || 0) + 1; });
  const groups = DEPT_ORDER.map((d) => [d, filtered.filter((c) => c.dept === d)]).filter((g) => g[1].length);
  const copy = (txt) => { try { navigator.clipboard.writeText(txt); } catch (e) {} setCopied(txt); setTimeout(() => setCopied(null), 1500); };

  return (
    <div className="page page-contacts">
      <div className="page-head">
        <div className="page-eyebrow">CONTACTS</div>
        <h1 className="page-title">Who knows what</h1>
        <p className="page-sub">
          {activeCount} active contributors{inactiveCount > 0 && <>, {inactiveCount} former</>}, grouped by team. Reach out directly for more context on an answer.
        </p>
        <div className="contact-controls">
          <div className="contact-search">
            <span className="search-icon"><Icon.Search /></span>
            <input value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="Search by name, role, or topic…" />
          </div>
          {inactiveCount > 0 && (
            <label className="toggle">
              <input type="checkbox" checked={showInactive} onChange={(e) => setShowInactive(e.target.checked)} />
              <span className="toggle-slider" />
              <span className="toggle-label">Show former staff</span>
            </label>
          )}
        </div>
        <div className="dept-chips">
          {["All", ...DEPT_ORDER.filter((d) => deptCounts[d])].map((d) => (
            <button key={d} className={"dept-chip" + (dept === d ? " on" : "")} onClick={() => setDept(d)}>
              {d}<span>{d === "All" ? Object.values(deptCounts).reduce((a, b) => a + b, 0) : deptCounts[d]}</span>
            </button>
          ))}
        </div>
      </div>
      {groups.map(([d, list]) => (
        <section key={d} className="dept-section">
          <h2 className="dept-title">{d}<span>{list.length}</span></h2>
          <div className="contacts-grid">
            {list.map((c) => (
              <article key={c.name} className={"contact-card " + (c.inactive ? "contact-inactive" : "")}>
                <div className="contact-top">
                  <Avatar name={c.name} size={44} />
                  <div className="contact-id">
                    <div className="contact-name">
                      {c.name}
                      {c.inactive && <span className="inactive-pill">Former</span>}
                    </div>
                    <div className="contact-role">{c.inactive ? (c.title ? c.title + " · No longer with the company" : "No longer with the company") : (c.title || <span className="role-tbc">Title to be confirmed</span>)}</div>
                    {!c.inactive && <button className="contact-email" onClick={() => copy(c.email)} title="Click to copy">{copied === c.email ? "Copied ✓" : c.email}</button>}
                  </div>
                </div>
                <div className="contact-topics">
                  <div className="contact-topics-label">Ask about</div>
                  <div className="contact-topic-list">
                    {c.topics.slice(0, 3).map((t) => (
                      <button key={t} className="contact-topic" title={t} onClick={() => { setQuery(t); setTab("wiki"); }}>{t}</button>
                    ))}
                    {c.topics.length === 0 && <span className="contact-topic-none">—</span>}
                  </div>
                </div>
                <div className="contact-stats">
                  <div><b>{c.count}</b><span>{c.count === 1 ? "entry" : "entries"}</span></div>
                  <div><b>{c.categories.size}</b><span>{c.categories.size === 1 ? "area" : "areas"}</span></div>
                  <div><b>{new Date(c.latest).toLocaleDateString(undefined, { month: "short", year: "numeric" })}</b><span>last</span></div>
                </div>
                <div className="contact-foot">
                  {!c.inactive ? <a className="reach-btn reach-primary" href={"mailto:" + c.email + "?subject=" + encodeURIComponent("Vendor wiki question")}>Email</a> : <span className="reach-btn reach-off" title="No longer with the company">Unavailable</span>}

                  <button className="ghost-btn" onClick={() => { setQuery(c.name); setTab("wiki"); }}>Entries</button>
                  <button className="ghost-btn" onClick={() => setOpenEntry([...c.entries].sort((a, b) => parseDate(b.date) - parseDate(a.date))[0])}>Latest</button>
                
                </div>
              </article>
            ))}
          </div>
        </section>
      ))}
      {filtered.length === 0 && <div className="empty-mini">No contacts match "<b>{filter}</b>".</div>}
    </div>
  );
}

// ---- Changelog view ----
function ChangelogView({ data, setOpenEntry }) {
  const buckets = useMemo(() => {
    const sorted = data.slice().sort((a, b) => parseDate(b.date) - parseDate(a.date));
    const map = new Map();
    for (const d of sorted) {
      const t = parseDate(d.date);
      const key = t ? new Date(t).toLocaleDateString(undefined, { month: "long", year: "numeric" }) : "Undated";
      if (!map.has(key)) map.set(key, []);
      map.get(key).push(d);
    }
    return [...map.entries()];
  }, [data]);

  return (
    <div className="page page-changelog">
      <div className="page-head">
        <div className="page-eyebrow">CHANGELOG</div>
        <h1 className="page-title">Recent activity</h1>
        <p className="page-sub">Every question and answer the wiki has captured, newest first.</p>
      </div>
      <div className="timeline">
        {buckets.map(([month, items]) => (
          <section key={month} className="timeline-bucket">
            <div className="timeline-month">
              <span>{month}</span>
              <span className="timeline-month-count">{items.length}</span>
            </div>
            <ol className="timeline-list">
              {items.map((d) => (
                <li key={d.id} className="timeline-item" onClick={() => setOpenEntry(d)}>
                  <div className="timeline-dot" data-status={d.status} />
                  <div className="timeline-body">
                    <div className="timeline-meta">
                      <span className="timeline-date">{d.date}</span>
                      <span className="dot">·</span>
                      <span className="timeline-cat">{d.category}</span>
                      <span className="crumb-sep">›</span>
                      <span className="timeline-sub">{d.subcategory}</span>
                      <StatusBadge status={d.status} />
                    </div>
                    <div className="timeline-q">{d.question}</div>
                    <div className="timeline-a">{(d.answer || "—").slice(0, 200)}{(d.answer || "").length > 200 ? "…" : ""}</div>
                    <div className="timeline-foot">
                      {d.appendix && APPENDICES[d.appendix] ? (
                        <span className="appendix-chip sm"><Icon.Doc /> Appendix {d.appendix}</span>
                      ) : (
                        <>
                          <Avatar name={d.author} size={20} />
                          <span>{d.author || "—"}</span>
                        </>
                      )}
                    </div>
                  </div>
                </li>
              ))}
            </ol>
          </section>
        ))}
      </div>
    </div>
  );
}

// ---- Appendix view ----
function AppendixView({ data, setOpenEntry }) {
  // Each section toggles independently. Default: all expanded.
  const [openIds, setOpenIds] = useState(() => new Set(Object.keys(APPENDICES)));
  const toggleOpen = (id) =>
    setOpenIds((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  const appendices = useMemo(() => {
    return Object.values(APPENDICES).map((ap) => {
      const entries = data.filter((d) => d.appendix === ap.id);
      const cats = {};
      for (const e of entries) cats[e.category] = (cats[e.category] || 0) + 1;
      return { ...ap, entries, cats };
    });
  }, [data]);

  return (
    <div className="page page-appendix">
      <div className="page-head">
        <div className="page-eyebrow">APPENDIX</div>
        <h1 className="page-title">Source documents</h1>
        <p className="page-sub">
          Some answers come from completed documents rather than Slack threads. Each appendix below is the original source — open it to see the full document, or collapse and expand any section to jump to the entries it backs.
        </p>
      </div>

      <div className="appendix-stack">
        {appendices.map((ap) => {
          const open = openIds.has(ap.id);
          return (
            <section key={ap.id} className={"appendix-card " + (open ? "open" : "")}>
              <header className="appendix-card-head" onClick={() => toggleOpen(ap.id)}>
                <div className="appendix-badge">{ap.id}</div>
                <div className="appendix-card-main">
                  <div className="appendix-card-title">{ap.title}</div>
                  <div className="appendix-card-meta">
                    <span className="appendix-type"><Icon.Doc /> {ap.type}</span>
                    <span className="dot">·</span>
                    <span>{ap.date}</span>
                    <span className="dot">·</span>
                    <span>{ap.entries.length} {ap.entries.length === 1 ? "entry" : "entries"}</span>
                  </div>
                </div>
                <div className="appendix-card-actions">
                  <a className="primary-btn sm" href={ap.url} target="_blank" rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()} style={{ textDecoration: "none" }}>
                    <Icon.Doc /> Open document
                  </a>
                  <button className="appendix-expand" aria-label={open ? "Collapse section" : "Expand section"} aria-expanded={open}>
                    <Icon.Chevron style={{ transform: open ? "rotate(90deg)" : "none", transition: "transform .18s" }} />
                  </button>
                </div>
              </header>

              {ap.description && <p className="appendix-desc">{ap.description}</p>}

              {open && (
                <div className="appendix-entries">
                  <div className="appendix-catbar">
                    {Object.entries(ap.cats).map(([c, n]) => (
                      <span key={c} className="appendix-cat-tag">{c} <b>{n}</b></span>
                    ))}
                  </div>
                  <ol className="appendix-entry-list">
                    {ap.entries.map((e) => (
                      <li key={e.id} className="appendix-entry" onClick={() => setOpenEntry(e)}>
                        <div className="appendix-entry-crumb">{e.category} <span className="crumb-sep">›</span> {e.subcategory}</div>
                        <div className="appendix-entry-q">{e.question}</div>
                        <div className="appendix-entry-a">{(plainText(e.answer) || "—").slice(0, 160)}{plainText(e.answer).length > 160 ? "…" : ""}</div>
                      </li>
                    ))}
                  </ol>
                </div>
              )}
            </section>
          );
        })}
      </div>
    </div>
  );
}

// ---- Root ----
function App() {
  const rawData = window.WIKI_DATA || [];
  const [edits, setEdits] = useState(() => {
    try { return JSON.parse(localStorage.getItem("wiki_edits") || "{}"); } catch { return {}; }
  });
  const data = useMemo(
    () => rawData.map((d) => (edits[d.id] ? { ...d, ...edits[d.id] } : d)),
    [edits]
  );
  const saveEdit = (id, patch) => {
    setEdits((prev) => {
      const next = { ...prev, [id]: { ...(prev[id] || {}), ...patch } };
      try { localStorage.setItem("wiki_edits", JSON.stringify(next)); } catch {}
      return next;
    });
  };
  const [tab, setTab] = useState("wiki");
  const [editor, setEditor] = useState(() => {
    try { return localStorage.getItem("wiki_editor") === "1"; } catch { return false; }
  });
  const [query, setQuery] = useState("");
  const [activeCat, setCat] = useState(null);
  const [activeSub, setSub] = useState(null);
  const [browseOpen, setBrowseOpen] = useState(false);
  const [tweaks, setTweaks] = useState(TWEAKS);
  const [tweaksVisible, setTweaksVisible] = useState(false);
  const [openEntry, setOpenEntry] = useState(null);

  // Click a suggestion chip → set the query AND, if there's an obvious best
  // match, jump straight into that entry's modal so the Slack link is one click away.
  const handleSuggest = (q) => {
    setQuery(q);
    setCat(null);
    setSub(null);
    const needle = q.toLowerCase();
    const tokens = needle.split(/\s+/).filter(Boolean);
    const scored = data
      .map((d) => {
        const hay = ((d.question || "") + " " + (d.answer || "") + " " + (d.category || "") + " " + (d.subcategory || "") + " " + (d.keywords || "")).toLowerCase();
        let score = 0;
        if (hay.includes(needle)) score += 10;
        for (const t of tokens) if (tokenHits(hay, t)) score += 1;
        return { d, score };
      })
      .filter((x) => x.score > 0)
      .sort((a, b) => b.score - a.score);
    if (scored.length && scored[0].score >= tokens.length) {
      setOpenEntry(scored[0].d);
    }
  };

  // Apply CSS vars from tweaks
  useEffect(() => {
    const r = document.documentElement.style;
    r.setProperty("--primary", tweaks.primaryColor);
    r.setProperty("--tint", tweaks.accentTint);
    document.body.dataset.density = tweaks.cardDensity;
  }, [tweaks]);

  // Edit-mode handshake
  useEffect(() => {
    const onMsg = (e) => {
      if (e.data?.type === "__activate_edit_mode") setTweaksVisible(true);
      if (e.data?.type === "__deactivate_edit_mode") setTweaksVisible(false);
    };
    window.addEventListener("message", onMsg);
    window.parent.postMessage({ type: "__edit_mode_available" }, "*");
    return () => window.removeEventListener("message", onMsg);
  }, []);

  const answeredCount = data.filter((d) => d.status === "answered").length;
  const reviewCount = data.filter((d) => d.status === "needs-review").length;
  const authorCount = new Set(data.map((d) => d.author).filter(Boolean)).size;

  return (
    <div className="app">
      <TopNav tab={tab} setTab={setTab} editor={editor} setEditor={setEditor} />
      {tab === "wiki" && (
        <>
          <Hero
            query={query}
            setQuery={setQuery}
            total={data.length}
            answered={answeredCount}
            needsReview={reviewCount}
            authors={authorCount}
            onSuggest={handleSuggest}
            heroStyle={tweaks.heroStyle}
          />
          <div className="layout">
            <Sidebar
              data={data}
              activeCat={activeCat}
              activeSub={activeSub}
              setCat={(c) => { setCat(c); setBrowseOpen(false); }}
              setSub={setSub}
              mobileOpen={browseOpen}
              onCloseMobile={() => setBrowseOpen(false)}
            />
            <Main
              data={data}
              query={query}
              setQuery={setQuery}
              activeCat={activeCat}
              activeSub={activeSub}
              setCat={setCat}
              setSub={setSub}
              tweaks={tweaks}
              openEntry={openEntry}
              setOpenEntry={setOpenEntry}
              onSave={saveEdit}
              editor={editor}
              onOpenBrowse={() => setBrowseOpen(true)}
            />
          </div>
        </>
      )}
      {tab === "submissions" && <SubmissionsView data={data} setOpenEntry={setOpenEntry} setTab={setTab} />}
      {tab === "corporate" && window.CorporateView && <window.CorporateView />}
      {tab === "compliance-platforms" && window.CompliancePlatformsView && <window.CompliancePlatformsView />}
      {tab === "insurance" && window.InsuranceView && <window.InsuranceView />}
      {tab === "contacts" && <ContactsView data={data} setOpenEntry={setOpenEntry} setQuery={setQuery} setTab={setTab} />}
      {tab === "appendix" && <AppendixView data={data} setOpenEntry={setOpenEntry} />}
      {tab === "changelog" && <ChangelogView data={data} setOpenEntry={setOpenEntry} />}
      {openEntry && tab !== "wiki" && <EntryModal entry={openEntry} onClose={() => setOpenEntry(null)} onSave={saveEdit} editor={editor}
        onNav={(cat, sub) => { setTab("wiki"); setCat(cat); setSub(sub); setOpenEntry(null); }} />}
      <TweaksPanel tweaks={tweaks} setTweaks={setTweaks} visible={tweaksVisible} onClose={() => setTweaksVisible(false)} />
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
